package uees.CalculadoraCO2;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class CalculadoraApp {

    // -------------------------------------------------------------------------
    // Método auxiliar: pide un número al usuario y repite hasta obtener uno
    // válido. Evita el crash por InputMismatchException cuando se escribe texto.
    // -------------------------------------------------------------------------
    private static double leerDouble(Scanner sc, String mensaje) {
        while (true) {
            System.out.print(mensaje);
            String entrada = sc.nextLine().trim();
            try {
                double valor = Double.parseDouble(entrada);
                return valor;
            } catch (NumberFormatException e) {
                System.out.println("  ✗ Entrada inválida. Ingrese un número (ej: 12.5).");
            }
        }
    }

    // -------------------------------------------------------------------------
    // Método auxiliar: pide un entero y repite hasta obtener uno válido.
    // -------------------------------------------------------------------------
    private static int leerInt(Scanner sc, String mensaje) {
        while (true) {
            System.out.print(mensaje);
            String entrada = sc.nextLine().trim();
            try {
                return Integer.parseInt(entrada);
            } catch (NumberFormatException e) {
                System.out.println("  ✗ Entrada inválida. Ingrese un número entero.");
            }
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        boolean salir = false;

        // FIX: lista que acumula todas las entradas para generar el reporte al salir.
        //      Antes, GestorArchivos.guardarReporte() nunca se llamaba.
        List<Reportable> registros = new ArrayList<>();

        while (!salir) {
            System.out.println("\n--- MENÚ PRINCIPAL ---");
            System.out.println("1. Transporte");
            System.out.println("2. Vivienda (Electricidad)");
            System.out.println("3. Alimentación");
            System.out.println("4. Consumo (Ropa)");
            System.out.println("5. Ver resumen de sesión");
            System.out.println("6. Salir y guardar reporte");

            int opcion = leerInt(sc, "Seleccione una opción: ");

            switch (opcion) {

                case 1:
                    System.out.println("Tipo de vehículo (CARRO / MOTO / BUS / MICROBUS): ");
                    String vehiculo = sc.nextLine().trim();
                    System.out.println("Tipo de combustible (GASOLINA / DIESEL / ELECTRICO): ");
                    String combustible = sc.nextLine().trim();
                    double km = leerDouble(sc, "Kilómetros recorridos: ");
                    try {
                        Transporte t = new Transporte(km, vehiculo, combustible);
                        registros.add(t);
                        System.out.println("✓ Registrado: " + t.obtenerDatosFila());
                    } catch (IllegalArgumentException e) {
                        System.out.println("  ✗ Error: " + e.getMessage());
                    }
                    break;

                case 2:
                    double consumo = leerDouble(sc, "Consumo eléctrico en kWh: ");
                    try {
                        Vivienda v = new Vivienda(consumo);
                        registros.add(v);
                        System.out.println("✓ Registrado: " + v.obtenerDatosFila());
                    } catch (IllegalArgumentException e) {
                        System.out.println("  ✗ Error: " + e.getMessage());
                    }
                    break;

                case 3:
                    // FIX: el menú ahora muestra ALTA_CARNE (con guión bajo),
                    //      que es lo que Alimentacion.java espera recibir.
                    System.out.print("Tipo de dieta (ALTA_CARNE / MEDIA / VEGETARIANA): ");
                    String dieta = sc.nextLine().trim();
                    double comidas = leerDouble(sc, "Número de comidas por semana: ");
                    try {
                        Alimentacion a = new Alimentacion(dieta, comidas);
                        registros.add(a);
                        System.out.println("✓ Registrado: " + a.obtenerDatosFila());
                    } catch (IllegalArgumentException e) {
                        System.out.println("  ✗ Error: " + e.getMessage());
                    }
                    break;

                case 4:
                    System.out.println("Opciones: NUEVA_IMPORTADA / NUEVA_NACIONAL / SEGUNDA_MANO");
                    System.out.print("Tipo de consumo: ");
                    String tipoConsumo = sc.nextLine().trim();
                    double prendas = leerDouble(sc, "Cantidad de prendas: ");
                    try {
                        Consumo c = new Consumo(tipoConsumo, prendas);
                        registros.add(c);
                        System.out.println("✓ Registrado: " + c.obtenerDatosFila());
                    } catch (IllegalArgumentException e) {
                        System.out.println("  ✗ Error: " + e.getMessage());
                    }
                    break;

                case 5:
                    // Resumen de la sesión actual
                    if (registros.isEmpty()) {
                        System.out.println("Aún no hay registros en esta sesión.");
                    } else {
                        double totalEmisiones = 0;
                        System.out.println("\n--- RESUMEN DE SESIÓN ---");
                        for (Reportable r : registros) {
                            System.out.println("  " + r.obtenerDatosFila());
                            // Extraer el último campo (emision) para sumar
                            String fila = r.obtenerDatosFila();
                            String[] partes = fila.split(",");
                            try {
                                totalEmisiones += Double.parseDouble(partes[partes.length - 1].trim());
                            } catch (NumberFormatException ignored) {}
                        }
                        System.out.printf("Total de emisiones: %.2f kgCO₂%n", totalEmisiones);
                    }
                    break;

                case 6:
                    salir = true;
                    // FIX: ahora se llama a GestorArchivos para generar el reporte CSV.
                    GestorArchivos.guardarReporte(registros);
                    System.out.println("Gracias por usar la calculadora de huella de carbono.");
                    break;

                default:
                    System.out.println("Opción inválida. Elija entre 1 y 6.");
            }
        }

        sc.close();
    }
}
